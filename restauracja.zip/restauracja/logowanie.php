<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <title>Restauracja Pod Niebieskim Kurem</title>
        <link rel="stylesheet" href="logowanie.css" type="text/css" />
    </head>
    <body>
       <h1>Restauracja Pod Niebieskim Kurem - Logowanie

<ol>
<li><a href="index.php">O nas</a>
<li><a href="menu.php">Menu</a>
<li><a href="#">Zamowienia</a>
<ul>
          <li><a href="#">Zloz Zamowienie</a></li>
          <li><a href="#">Status Zamowienia</a></li>
        
        </ul>

<li><a href="logowanie.php">Konto</a>
    
         
               
       
      </li>
  </ul>
</h1>
     <h6>
        <center>
        
           <form class="formularzlogowania" action="login.php" method="post">
           <input class="username " placeholder="Nazwa użytkownika" type="text" name="username"  />  <br/> 
           <input class="pass" type="password" placeholder="Hasło" name="password" />

          <br/> <br/>
             <button class="button" name="submit" type="submit">Zaloguj</button> <br/> <br/>
             Nie masz konta? <a href="rejestracja.php">Zarejestruj się</a> <br/>
             
           </form>
           
           <?php
           if(isset($_SESSION['blad'] ))
           echo $_SESSION['blad']; 
            
           
           ?>
        </center>
        
</h6>
            

        </section>

</body>