<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>Restauracja Pod Niebieskim Kurem</title>
    <link rel="stylesheet" href="styl.css" type="text/css" />
    <style>
@import url('https://fonts.googleapis.com/css2?family=Lora&family=Source+Serif+Pro:wght@300&display=swap');
</style>
</head>
<body>
       <h1>Restauracja Pod Niebieskim Kurem - O nas 

<ol>
<li><a href="index.php">O nas</a>
<li><a href="menu.php">Menu</a>
<li><a href="#">Zamowienia</a>
<ul>
          <li><a href="#">Zloz Zamowienie</a></li>
          <li><a href="#">Status Zamowienia</a></li>
        
        </ul>

<li><a href="logowanie.php">Konto</a>
       
         
               
       
      </li>
  </ul>
</h1>
<section class ="main container">
<span style ="font-size: 25px "><p class="double">Historia naszej restauracji</p></span>


<div class="row">
  <div class="column col-6">
    
    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book..</p>
  </div>
  <div class="column col-6">
    
    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
  </div>
</div>
</section>
</body>
</html>