<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restauracja Pod Niebieskim Kurem</title>
    <link rel="stylesheet" href="rejestracja.css" type="text/css" />
</head>
<body>
       <h1>Restauracja Pod Niebieskim Kurem - O nas 

<ol>
<li><a href="index.php">O nas</a>
<li><a href="menu.php">Menu</a>
<li><a href="#">Zamowienia</a>
<ul>
          <li><a href="#">Zloz Zamowienie</a></li>
          <li><a href="#">Status Zamowienia</a></li>
        
        </ul>

<li><a href="logowanie.php">Konto</a>
       
         
               
       
      </li>
  </ul>
</h1>
<center>
<form class="formularzlogowania" action="register.php" method="post">
           <input class="username" placeholder="Nazwa użytkownika" type="text" name="username"  />  <br/> 
           <input class="pass" type="password" placeholder="Hasło" name="password" />

          <br/> <br/>
             <button class="button" name="submit" type="submit">
                 <a href="register.php"></a>Zarejestruj</button> <br/> <br/>
             
           </form>
           <?php
           if(isset($_SESSION['registered'])){
            echo $_SESSION['registered']; 
           }
           

           if(isset($_SESSION['register_err'])){
            echo $_SESSION['register_err']; 
           }
           
           ?>
</center>
</div>
</div>
</section>
</body>
</html>