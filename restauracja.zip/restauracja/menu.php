<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>Restauracja Pod Niebieskim Kurem</title>
    <link rel="stylesheet" href="menu.css" type="text/css" />
</head>
<body>
       <h1>Restauracja Pod Niebieskim Kurem - Menu

<ol>
<li><a href="index.php">O nas</a>
<li><a href="menu.php">Menu</a>
<li><a href="#">Zamowienia</a>
<ul>
          <li><a href="#">Zloz Zamowienie</a></li>
          <li><a href="#">Status Zamowienia</a></li>
        
        </ul>

<li><a href="logowanie.php">Konto</a>
       
         
               
       
      </li>
  </ul>
</h1>
<br>
<div clas="container">
    <div class="row">
        <div class="col-12">
            
        <center>   <h1 class="menu">Menu</h1><div class="dania">
                <?php
                
                $db="3c1";
                $conn = new mysqli("localhost","root","",$db);
                if ($conn -> connect_error){
                    die("Połącznie nieudane".$conn ->connect_error);
                }
                
                $sql="select nazwa,cena from dania";
                $result= $conn ->query($sql);
                echo "<table><th><h3>Dania</h3></th><th><h3>Cena</h3></th>";
                while($row=$result ->fetch_assoc()){
            
                    
                    echo "<tr><td>".$row["nazwa"]."</td>";
                    echo "<td>".$row["cena"]."</td></tr>";
                }
                
                $conn -> close();
                echo "</table>";
                ?>
            </center></div></div>
              
        </div>
        
    </div>
</div>

    
</body>
</html>