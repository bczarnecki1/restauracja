<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styl.css" type="text/css" />
</head>
<body>
       <h1><a href="index.php">Restauracja Pod Niebieskim Kurem</a>

<ol>
<li><a href="menu.php">Menu</a>
<li><a href="zamowienia.php">Zamowienia</a>


<li><a href="#">Konto</a>
        <ul>
          <li><a href="#">Zaloguj się</a></li>
          <li><a href="#">Załóż konto</a></li>
        
        </ul>
      </li>

      

    
  </ul>
</div>
</h1>
<div id="footer">Twoje zamowienie</div>
</section>
</body>
</html>